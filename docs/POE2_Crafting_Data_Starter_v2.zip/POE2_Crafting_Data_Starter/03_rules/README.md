# 제작 규칙 디렉터리

실제 검증 후 `currency_rules.json`, `omen_rules.json`, `essence_rules.json`, `special_rules.json` 또는 같은 기능의 TypeScript 모듈을 추가합니다.

**출발 파일:** `rule_registry.template.json`. 모든 레코드는 `enabled=false` + `verification_status=unverified` 예시이므로 **바로 실행하면 안 됩니다.** 각 재료의 정확한 한국어명, 희귀도·아이템레벨 제한, 후보 선정, 예외를 `docs/IMPLEMENTATION_CONTRACT.md` 방식으로 확인한 후 개별적으로 승인합니다.

오브 사용불가/미검증 규칙은 아이템·재료 차감 없이 한국어 이유 표시.
