# 통합 데이터

원본 데이터를 여기서 생성한 `bases.json`, `affixes.json`, `weights.json`, `currency.json`, `omens.json`, `essences.json`, `specials.json`, `names_ko.json` 파일로 정규화합니다.

모든 기록에 source revision, patch version, verification status를 첨부하고 **미검증 가중치를 1로 채우지 말 것**. `docs/schema_contract.md`와 `docs/IMPLEMENTATION_CONTRACT.md` 참고. 현재 **실제 데이터는 포함되지 않음**.
