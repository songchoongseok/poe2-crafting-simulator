# POE2 Community Path of Building public source snapshot downloader.
# Runs ONLY when you explicitly execute this script on your own PC.
# Does not fetch PoE2DB, game client files, or copyrighted images.
$ErrorActionPreference = "Stop"
$root = Split-Path -Parent $MyInvocation.MyCommand.Path
$downloads = Join-Path $root '00_downloads'
$raw = Join-Path $root '01_raw\pob2'
New-Item -ItemType Directory -Force -Path $downloads, $raw | Out-Null
$url = 'https://github.com/PathOfBuildingCommunity/PathOfBuilding-PoE2/archive/refs/heads/dev.zip'
$zip = Join-Path $downloads 'PathOfBuilding-PoE2-dev.zip'
Write-Host 'Downloading public PoB2 source snapshot...'
Invoke-WebRequest -Uri $url -OutFile $zip
$hash = (Get-FileHash -Algorithm SHA256 -Path $zip).Hash
$stamp = Get-Date -Format o
@("source=$url", "captured_at=$stamp", "sha256=$hash") | Set-Content -Encoding UTF8 (Join-Path $downloads 'pob2_snapshot.txt')
Expand-Archive -LiteralPath $zip -DestinationPath $raw -Force
Write-Host "Saved: $zip"
Write-Host "SHA256: $hash"
Write-Host "Extracted: $raw"
Write-Host 'Review exact commit SHA separately and pin it for reproducibility.'
