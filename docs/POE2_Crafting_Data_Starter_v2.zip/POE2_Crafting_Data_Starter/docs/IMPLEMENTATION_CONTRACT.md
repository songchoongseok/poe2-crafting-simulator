# 구현 계약 (Implementation Contract)

## 데이터 로딩 파이프라인

`download → pin revision & sha256 → parse Lua → POE2-only filtering → normalize IDs → names_ko join → spawn weights join → validate → approved snapshot → JS bundle → HTML`

원본은 `01_raw`에서 보존하고, 변환 결과는 `02_normalized`에 씀. 각 스냅샷에 `schema_version`, `game_patch`, `source_commit`, `created_at`, `validation_report`를 포함. 서로 다른 패치 버전을 섞지 않음. 사용자에게는 데이터 스냅샷 및 지원되는 제작 재료 범위를 보여준다.

### 초기 정규화 파일(개발자가 먼저 생성)

- `bases.json`: 기본 성능, 타입/태그, 장착 최소레벨, 고정 속성, POE2 현재 사용가능 여부
- `affixes.json`: mod ID/그룹/티어/속성 레벨/접두·접미/수치/태그/베이스 조건
- `weights.json`: 항목별 등장 가중치, 태그별 override, 출처, 검증 상태 (`null`이면 확률계산 불가)
- `currency.json`: 오브 이름/등급/희귀도/속성 필터/적용 가능 조건/효과
- `omens.json`: 발동 화폐, 조건, 선택 방향/소모 규칙/검증 상태
- `essences.json`: 대상 희귀도, 확정 부여되는 속성 및 기존 상태 변화 규칙
- `specials.json`: 분열, 뼈, 훼손/미공개 공개, 보조 제작 예외
- `names_ko.json`: 기준 ID ↔ 원문/한국어명; 번역만으로 연결 금지

### 엔진 인터페이스 (예시 TypeScript 타입)

```ts
type Verification = 'verified'|'partial'|'unverified';
type AffixKind = 'prefix'|'suffix';
type Rarity = 'normal'|'magic'|'rare';
type ModState = 'ordinary'|'fractured'|'crafted'|'desecrated_revealed'|'desecrated_hidden';

type Item = {
  baseId: string;
  itemLevel: number;
  rarity: Rarity;
  implicitModIds: string[];
  explicitMods: Array<{
    instanceId: string;
    modId: string | null; // hidden mod: ID might be unresolved
    kind: AffixKind | 'unknown';
    groupId?: string;
    tier?: number;
    rolledValues?: number[];
    state: ModState;
  }>;
  activeOmens: string[];
  corrupted: boolean;
};

type Action = { actionId: string; targetModId?: string; args?: Record<string, unknown> };
type ErrorResult = { ok: false; errorCode: string; messageKo: string; details: string[]; stateUnchanged: true };
type SuccessResult = {
  ok: true;
  before: Item;
  after: Item;
  consumed: Record<string, number>;
  rngSeed: string;
  rollTrace: Array<{ poolSize: number; totalWeight?: number; selectedModId?: string }>;
};

declare function canApply(item: Item, action: Action, snapshot: object): ErrorResult | {ok: true};
declare function apply(item: Item, action: Action, seed: string, snapshot: object): ErrorResult | SuccessResult;
```

### 검증기 / 재료 원자성

`canApply`가 `ok=false`면 **절대 mutate하지 않음**. `apply`는 입력 item을 복제하여 처리 후 성공시에만 소비와 상태를 함께 커밋. 순서는 화폐별 규칙 테이블에서 지정(공통 순서로 과도한 일반화 금지). 징조는 어떤 단계에서 적용되고 언제 소모되는지 명시적으로 따로 정의. 여러 효과가 동시에 발동할 때 우선순위 충돌 시 `UNVERIFIED_RULE` 반환.

### 오류 코드 필수 목록

- `WRONG_GAME_VERSION`: POE1 전용/미출시/지원 패치 바깥
- `INVALID_ITEM_CLASS`: 그 아이템 유형에 사용 불가
- `INVALID_RARITY`: 희귀도 조건 위반
- `NO_AVAILABLE_SLOT`: 추가 가능한 접두/접미 자리 없음
- `LEVEL_TOO_LOW`: 요구 아이템 레벨 미달
- `MOD_GROUP_BLOCKED`: 기존 속성 그룹 충돌
- `NO_ELIGIBLE_MODS`: 생성 가능한 후보 없음
- `TARGET_PROTECTED`: 고정/보호 속성 제거 시도
- `INVALID_OMEN_COMBO`: 징조 + 화폐 조합 불가
- `MISSING_WEIGHT`: 필수 후보 등장 가중치 미확보
- `UNVERIFIED_RULE`: 실행에 필요한 제작 규칙 미검증
- `INSUFFICIENT_INVENTORY`: 재료 잔량 부족

각 오류에는 사용자에게 보여줄 **한국어 이유와 복구 방법**을 적는다. 부분 소모 금지.

## 속성 추첨 함수

```text
pool = all affixes for item class & base tags
pool = filter by game_patch, active_in_PoE2, item_level>=required_item_level
pool = filter by current action: min_mod_level, prefix/suffix direction, spawn tags
pool = filter by free explicit slots and mod_group collision
pool = filter by item special restrictions / fractured / crafted / desecrated exception
if pool empty: NO_ELIGIBLE_MODS
if ANY eligible candidate lacks verified weight: MISSING_WEIGHT
p(target) = sum(weights of targeted mods) / sum(weights of all eligible mods)
roll using seeded RNG and recorded weight intervals
```

숫자 `1`이 파일에서 보인다는 이유만으로 가중치 1이라 가정하지 않는다. POE2 특수 규칙으로 인해 어떤 후보가 다른 단계에서 제외/포함될 수 있음에 주의. 특정 오브 사용 시 **먼저 제거해 중복 그룹을 해제한 다음 새로운 옵션을 뽑는지** 등 구체 순서를 규칙별로 검증한다.

## 통계 API

```ts
type Goal = { desiredModIds: string[]; minRolls?: Record<string, number> };
type Strategy = { start: Item; steps: WorkflowStep[]; maxSteps: number; maxBudget?: number };
type Summary = {
  successRate: number | null;
  perStepProbability: Record<string, number | null>;
  consumptionMean: Record<string, number> | null;
  consumptionP90: Record<string, number> | null;
  restartsMean: number | null;
  method: 'exact' | 'monte_carlo' | 'hypothetical' | 'unavailable';
  rngSeed?: string;
  iterations?: number;
};
```

조건부 확률·실패 복구·특수 제작 등이 들어간 루프는 경로가 달라지므로, `1/p`를 모든 단계에 기계적으로 넣지 않는다. 독립 고정 확률 상황에서는 `E[N]=1/p`, `N90=ceil(log(0.1)/log(1-p))`; 루프가 상태를 변경하면 상태 전이 혹은 Monte Carlo로 추정. 90% 준비량은 **전략 전체 성공을 위한 분포**와 **개별 단계 재료 90백분위**를 혼동하지 않도록 별도 필드로 보여준다. 무한루프/소멸가능 상태를 검사한다.

## Workflow 출력 계약

`WorkflowStep`은 다음 필드 포함: `id`, `title_ko`, `material_ids`, `before_state_query`, `action`, `success_test`, `on_success`, `on_failure`, `recovery`, `risk_tags`, `verification`.

PDF 첫 페이지는 `rankdir=TB`와 명시적 START/FINISH를 유지하되, 실제 레이아웃에서는 **종료 조건을 만족하는 경로를 한 곳의 FINISH에 수렴**시킨다. 실패 루프는 측면으로 돌아오도록 배치한다. 새 베이스는 별도의 START로 만들지 않고 '베이스 확보'로 연결. 상세 설명은 **그 step IDs를 그대로 순회해 생성**하며 '화면엔 없는데 설명에는 있는 단계'가 없어야 한다. PDF 텍스트 잘림은 페이지별 렌더 후 확인.

## 로컬 실행

HTML 단일 파일 실행 목표라면 JS+검증된 데이터 스냅샷을 빌드 시 `app.bundle.js` 안에 내장하거나 `offline.html` 안에 삽입한다. `file://`에서 JSON `fetch`를 기본 동작으로 의존하지 않는다. 외부 CDN/폰트/스크립트 의존성은 제거. 별도 HTTP 서버를 쓴다면 사용자에게 설치·실행 필요성을 명시한다.
