# 데이터 정의 (1차)

## bases.json
`base_id`, `item_class`, `name_en`, `name_ko`, `base_min_level`, `stat_requirements`, `base_stats`, `tags`, `implicit_mod_ids`, `valid_in_poe2`, `source_meta`

## affixes.json
`mod_id`, `family`, `group`, `type`(prefix/suffix), `tier`, `required_item_level`, `rolls_min_max`, `stat_tags`, `spawn_rules`, `source_meta`

## weights.json
`mod_id`, `item_class_or_tag`, `weight`, `weight_source`, `weight_verified`, `patch_version`, `notes`  
**실제 weight 미확인 시 반드시 `null`, 임의의 1로 채우지 않음.**  
모드 가중치는 아이템 태그·중복 그룹·기존 속성·등급·신규 속성 최소 레벨 필터 후 합산.

## currencies.json / omens.json / essences.json / abyss.json
`id`, `name_ko`, `name_en`, `allowed_item_classes`, `rarity_preconditions`, `slot_preconditions`, `trigger`, `effect`, `exceptions`, `source_meta`

## crafting state
`base_id`, `item_level`, `rarity`, `prefixes[]`, `suffixes[]`, `fractured_mod_ids[]`, `crafted_mod_ids[]`, `unrevealed_desecrated_slots`, `corrupted`, `active_omens[]`, `consumption_log[]`

## 각 레코드 provenance
`source_url`, `source_revision_or_captured_at`, `patch_version`, `validation_status`, `checked_against_game`, `notes`.
